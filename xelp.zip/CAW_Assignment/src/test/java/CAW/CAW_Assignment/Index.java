package CAW.CAW_Assignment;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Index {
	WebDriver driver;
	
@BeforeTest
	public void setUp() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","C:\\Selenium\\chromedriver.exe");	
		 driver= new ChromeDriver();
		driver.get("https://testpages.herokuapp.com/styled/tag/dynamic-table.html");
		driver.manage().window().maximize();
		
	}
		
@Test		
		public void web() throws InterruptedException
		{
	
		driver.findElement(By.cssSelector("a[href='../index.html']")).click();
		WebElement basic=driver.findElement(By.xpath("//a[@id='basicpagetest']"));
		basic.click();
		System.out.println(driver.getTitle());
	
		driver.navigate().back();
		
		}
@Test
public void attribute() throws InterruptedException
{

	driver.findElement(By.xpath("//a[@id='elementattributestest']")).click();
	Thread.sleep(2000);
	driver.findElement(By.cssSelector(".styled-click-button")).click();
	
	
}
@Test
public void play() throws InterruptedException
{
	driver.findElement(By.id("findbytest")).click();
	List<WebElement> para=driver.findElements(By.name("ulName1"));
	System.out.println(para.size());
	driver.findElement(By.name("aName26")).click();
	driver.findElement(By.name("aName27")).click();
	driver.findElement(By.name("aName28")).click();
	driver.findElement(By.name("aName29")).click();
	driver.findElement(By.name("aName30")).click();
	driver.findElement(By.name("aName31")).click();
	
	Thread.sleep(3000);
	

}

@Test
public void example()
{
	driver.get("https://testpages.eviltester.com/styled/index.html");
	driver.findElement(By.id("webdriverexamplepage")).click();
	driver.findElement(By.id("numentry")).sendKeys("1234");
	driver.findElement(By.id("submit-to-server")).click();
	WebElement text=driver.findElement(By.id("message"));
	System.out.println(text.getText());
	driver.findElement(By.id("show-as-alert")).click();
	
	driver.switchTo().alert().getText();
	driver.switchTo().alert().accept();
	driver.findElement(By.id("clickable-link")).click();
	System.out.println(driver.findElement(By.id("message")).getText());
}

@Test
public void tag()
{
	driver.get("https://testpages.eviltester.com/styled/index.html");
	driver.findElement(By.id("tablestest")).click();
	System.out.println(driver.findElement(By.xpath("//table[@id='mytable']//th")).getSize());
	System.out.println(driver.findElement(By.xpath("tbody tr:nth-child(2) td:nth-child(1)")).getText());
	
}
	
@Test
public void tearDown()
{
	driver.close();
}

	

		
		
		

}
