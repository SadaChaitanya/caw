package CAW.CAW_Assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class alert {
	
	WebDriver driver;
	@Test
	public void setUp() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","C:\\Selenium\\chromedriver.exe");	
		 driver= new ChromeDriver();
		driver.get("https://testpages.eviltester.com/styled/index.html");
		driver.manage().window().maximize();
		
		driver.findElement(By.id("alerttest")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("alertexamples")).click();
		driver.switchTo().alert().accept();
		String tx=(driver.findElement(By.id("alertexplanation")).getText());
		String at="You triggered and handled the alert dialog";
		Assert.assertEquals(tx, at);
		driver.findElement(By.id("confirmexample")).click();
		driver.switchTo().alert().accept();
		String tl=(driver.findElement(By.id("confirmexplanation")).getText());
		String al="You clicked OK, confirm returned ";
		Assert.assertEquals(tl, al);
		
		
			
				 
		
	}
	
}
